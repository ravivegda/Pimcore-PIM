-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: pimcore
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.14-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `classificationstore_keys`
--

DROP TABLE IF EXISTS `classificationstore_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `classificationstore_keys` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `storeId` int(11) DEFAULT NULL,
  `name` varchar(190) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  `type` varchar(190) DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT 0,
  `modificationDate` int(11) unsigned DEFAULT 0,
  `definition` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`definition`)),
  `enabled` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `enabled` (`enabled`),
  KEY `type` (`type`),
  KEY `storeId` (`storeId`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_keys`
--

LOCK TABLES `classificationstore_keys` WRITE;
/*!40000 ALTER TABLE `classificationstore_keys` DISABLE KEYS */;
INSERT INTO `classificationstore_keys` VALUES (1,1,'Chipset','Chipset',NULL,'input',1757326444,1757392594,'{\"fieldtype\":\"input\",\"name\":\"Chipset\",\"title\":\"Chipset\",\"datatype\":\"data\"}',0),(2,1,'Socket','Socket',NULL,'input',1757326461,1757392598,'{\"fieldtype\":\"input\",\"name\":\"Socket\",\"title\":\"Socket\",\"datatype\":\"data\"}',0),(3,1,'Format','Format',NULL,'input',1757326467,1757392616,'{\"fieldtype\":\"input\",\"name\":\"Format\",\"title\":\"Format\",\"datatype\":\"data\"}',0),(4,1,'Memory Type','Memory Type',NULL,'input',1757326507,1757392612,'{\"fieldtype\":\"input\",\"name\":\"Memory Type\",\"title\":\"Memory Type\",\"datatype\":\"data\"}',0),(5,1,'size','size',NULL,'input',1757327105,1757392603,'{\"fieldtype\":\"input\",\"name\":\"size\",\"title\":\"size\",\"datatype\":\"data\"}',0),(6,1,'resolution','resolution',NULL,'input',1757327115,1757392609,'{\"fieldtype\":\"input\",\"name\":\"resolution\",\"title\":\"resolution\",\"datatype\":\"data\"}',0),(7,1,'Response Time','Response Time',NULL,'input',1757327130,1757392606,'{\"fieldtype\":\"input\",\"name\":\"Response Time\",\"title\":\"Response Time\",\"datatype\":\"data\"}',0),(8,1,'Colour','Colour',NULL,'select',1757392659,1757392960,'{\"name\":\"Colour\",\"datatype\":\"data\",\"fieldtype\":\"select\",\"title\":\"Colour\",\"options\":[{\"key\":\"Red\",\"value\":\"Red\"},{\"key\":\"Blue\",\"value\":\"Blue\"},{\"key\":\"Green\",\"value\":\"Green\"},{\"key\":\"Yellow\",\"value\":\"Yellow\"},{\"key\":\"Orange\",\"value\":\"Orange\"},{\"key\":\"White\",\"value\":\"White\"},{\"key\":\"Black\",\"value\":\"Black\"},{\"key\":\"Pink\",\"value\":\"Pink\"},{\"key\":\"Brown\",\"value\":\"Brown\"}],\"tooltip\":\"\",\"mandatory\":false,\"index\":false,\"noteditable\":false,\"invisible\":false,\"visibleGridView\":false,\"visibleSearch\":false,\"style\":\"\",\"width\":\"\",\"displayfield-2731-inputEl\":\"The width of this component. A numeric value will be interpreted as the number of pixels; a string value will be treated as a CSS value with units.\",\"defaultValue\":\"\",\"defaultValueGenerator\":\"\",\"optionsProviderType\":\"configure\",\"optionsProviderClass\":\"\",\"optionsProviderData\":\"\",\"combobox-2726-inputEl\":null}',1),(9,1,'Size','Size',NULL,'numeric',1757392664,1757392758,'{\"fieldtype\":\"numeric\",\"name\":\"Size\",\"title\":\"Size\",\"datatype\":\"data\"}',1),(10,1,'Weight','Weight',NULL,'numeric',1757392680,1757392777,'{\"fieldtype\":\"input\",\"name\":\"Weight\",\"title\":\"Weight\",\"datatype\":\"data\"}',1),(11,1,'Brand','Brand',NULL,'input',1757392685,1757392685,'{\"fieldtype\":\"input\",\"name\":\"Brand\",\"title\":\"Brand\",\"datatype\":\"data\"}',1),(12,1,'Material','Material',NULL,'input',1757392985,1757392985,'{\"fieldtype\":\"input\",\"name\":\"Material\",\"title\":\"Material\",\"datatype\":\"data\"}',1),(13,1,'Warranty','Warranty',NULL,'numeric',1757392992,1757393012,'{\"fieldtype\":\"numeric\",\"name\":\"Warranty\",\"title\":\"Warranty\",\"datatype\":\"data\"}',1);
/*!40000 ALTER TABLE `classificationstore_keys` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12 20:39:13
