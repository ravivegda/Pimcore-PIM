-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: pimcore
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.14-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `ctype` enum('asset','document','object') DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `user` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `locked` tinyint(1) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `cid_ctype` (`cid`,`ctype`),
  KEY `date` (`date`),
  KEY `user` (`user`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` VALUES (1,'Status update',35,'object',1757515813,2,'Review to Approved','',1),(2,'Status update',33,'object',1757515837,2,'Review to Approved','',1),(3,'Status update',35,'object',1757516093,2,'Approved to Rejected','',1),(4,'Status update',35,'object',1757516197,2,'Approved to Rejected','',1),(5,'Status update',35,'object',1757516202,2,'Draft to Review','',1),(6,'Status update',35,'object',1757523364,2,'Review to Approved','',1),(7,'workflow',39,'object',1757524243,2,'Workflow Transition','Product moved from \"draft\" to \"review\" via transition \"to_review\"',1),(8,'Status update',39,'object',1757524243,2,'Draft to Review','',1),(9,'workflow',41,'object',1757578586,6,'Workflow Transition','Product moved from \"draft\" to \"review\" via transition \"to_review\"',1),(10,'Status update',41,'object',1757578586,6,'Draft to Review','',1),(11,'workflow',41,'object',1757580577,8,'Workflow Transition','Product moved from \"review\" to \"approved\" via transition \"to_approve\"',1),(12,'Status update',41,'object',1757580577,8,'Review to Approved','',1),(13,'workflow',43,'object',1757580831,2,'Workflow Transition','Product moved from \"draft\" to \"review\" via transition \"to_review\"',1),(14,'Status update',43,'object',1757580831,2,'Draft to Review','',1),(15,'workflow',43,'object',1757580954,8,'Workflow Transition','Product moved from \"review\" to \"approved\" via transition \"to_approve\"',1),(16,'Status update',43,'object',1757580954,8,'Review to Approved','',1),(17,'workflow',45,'object',1757581584,8,'Workflow Transition','Product moved from \"draft\" to \"review\" via transition \"to_review\"',1),(18,'Status update',45,'object',1757581584,8,'Draft to Review','',1);
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12 20:39:13
