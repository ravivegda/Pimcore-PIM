-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: pimcore
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.14-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `object_classificationstore_data_Product`
--

DROP TABLE IF EXISTS `object_classificationstore_data_Product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_classificationstore_data_Product` (
  `id` int(11) unsigned NOT NULL,
  `collectionId` bigint(20) DEFAULT NULL,
  `groupId` int(11) unsigned NOT NULL,
  `keyId` bigint(20) NOT NULL,
  `value` longtext DEFAULT NULL,
  `value2` longtext DEFAULT NULL,
  `fieldname` varchar(70) NOT NULL,
  `language` varchar(10) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`,`fieldname`,`groupId`,`keyId`,`language`),
  KEY `keyId` (`keyId`),
  KEY `language` (`language`),
  KEY `groupKeys` (`id`,`fieldname`,`groupId`),
  CONSTRAINT `fk_object_classificationstore_data_Product__id` FOREIGN KEY (`id`) REFERENCES `objects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_object_classificationstore_data_Product__id__fieldna_cb9ca2a2` FOREIGN KEY (`id`, `fieldname`, `groupId`) REFERENCES `object_classificationstore_groups_Product` (`id`, `fieldname`, `groupId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_classificationstore_data_Product`
--

LOCK TABLES `object_classificationstore_data_Product` WRITE;
/*!40000 ALTER TABLE `object_classificationstore_data_Product` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_classificationstore_data_Product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12 20:39:13
