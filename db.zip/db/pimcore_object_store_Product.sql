-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: pimcore
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.14-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `object_store_Product`
--

DROP TABLE IF EXISTS `object_store_Product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_store_Product` (
  `oo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `productName` varchar(190) DEFAULT NULL,
  `description` varchar(190) DEFAULT NULL,
  `productId` double DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `productImage` int(11) DEFAULT NULL,
  `SKU` varchar(190) DEFAULT NULL,
  `nextAvailableOn` date DEFAULT NULL,
  `stockQuantity` double DEFAULT NULL,
  `priceUpdatedAt` datetime DEFAULT NULL,
  `price` double DEFAULT NULL,
  `workflowTransition` varchar(190) DEFAULT NULL,
  PRIMARY KEY (`oo_id`),
  UNIQUE KEY `u_index_SKU` (`SKU`),
  CONSTRAINT `fk_object_store_Product__oo_id` FOREIGN KEY (`oo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_store_Product`
--

LOCK TABLES `object_store_Product` WRITE;
/*!40000 ALTER TABLE `object_store_Product` DISABLE KEYS */;
INSERT INTO `object_store_Product` VALUES (35,'tespro','weewqe',123456,'2025-09-10 03:45:13',NULL,'SKU-002',NULL,17,NULL,NULL,NULL),(37,NULL,NULL,NULL,'2025-09-10 13:49:08',NULL,'SKU-003',NULL,NULL,NULL,NULL,NULL),(39,'teslog','frtft',655,'2025-09-10 17:02:59',NULL,'SKU-004',NULL,10,NULL,NULL,NULL),(41,'testuser','uygft',97,'2025-09-11 08:13:38',NULL,'SKU-005',NULL,20,NULL,NULL,NULL),(43,'test12','fdde',123,'2025-09-11 08:43:05',NULL,'SKU-006',NULL,10,NULL,NULL,NULL),(45,'hfgvs','hghb',977,'2025-09-11 08:58:31',NULL,'SKU-007',NULL,19,NULL,NULL,NULL),(47,'testwork','ghfgf',7665,'2025-09-11 09:40:55',NULL,'SKU-008',NULL,90,NULL,NULL,NULL),(49,'testPr','hvff',12,'2025-09-11 13:03:20',NULL,'SKU-009',NULL,10,'2025-09-11 18:38:50',692,NULL),(51,'Bottle','pink bottle',NULL,'2025-09-11 19:59:14',NULL,'SKU-010','2025-09-18',0,'2025-09-11 19:59:14',20,NULL),(56,'Pot','pink bottle',NULL,'2025-09-12 14:54:31',NULL,'SKU-011','2025-09-18',0,'2025-09-12 14:54:31',20,NULL);
/*!40000 ALTER TABLE `object_store_Product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12 20:39:13
