-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: pimcore
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.14-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `objects`
--

DROP TABLE IF EXISTS `objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `objects` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(11) unsigned DEFAULT NULL,
  `type` enum('object','folder','variant') DEFAULT NULL,
  `key` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '',
  `path` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `index` int(11) unsigned DEFAULT 0,
  `published` tinyint(1) unsigned DEFAULT 1,
  `creationDate` int(11) unsigned DEFAULT 0,
  `modificationDate` int(11) unsigned DEFAULT 0,
  `userOwner` int(11) unsigned DEFAULT NULL,
  `userModification` int(11) unsigned DEFAULT NULL,
  `classId` varchar(50) DEFAULT NULL,
  `className` varchar(255) DEFAULT NULL,
  `childrenSortBy` enum('key','index') DEFAULT NULL,
  `childrenSortOrder` enum('ASC','DESC') DEFAULT NULL,
  `versionCount` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fullpath` (`path`,`key`),
  KEY `key` (`key`),
  KEY `index` (`index`),
  KEY `published` (`published`),
  KEY `parentId` (`parentId`),
  KEY `type_path_classId` (`type`,`path`,`classId`),
  KEY `modificationDate` (`modificationDate`),
  KEY `classId` (`classId`),
  KEY `versionCount` (`versionCount`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `objects`
--

LOCK TABLES `objects` WRITE;
/*!40000 ALTER TABLE `objects` DISABLE KEYS */;
INSERT INTO `objects` VALUES (1,0,'folder','','/',999999,1,1756188640,1756188640,1,1,NULL,NULL,NULL,NULL,0),(21,1,'folder','Category','/',0,1,1757328430,1757328430,2,2,NULL,NULL,NULL,NULL,2),(22,21,'object','Electronics','/Category/',0,1,1757328440,1757329021,2,2,'Category','Category',NULL,NULL,4),(26,22,'object','Mobiles','/Category/Electronics/',0,1,1757329318,1757474842,2,2,'Category','Category',NULL,NULL,9),(27,1,'folder','Product','/',0,1,1757393213,1757393213,2,2,NULL,NULL,NULL,NULL,2),(34,27,'folder','SKU-002','/Product/',0,1,1757475913,1757475913,2,2,NULL,NULL,NULL,NULL,1),(35,34,'object','NextPro','/Product/SKU-002/',0,0,1757475913,1757523734,2,2,'Product','Product',NULL,NULL,10),(36,27,'folder','SKU-003','/Product/',0,1,1757512148,1757512148,2,2,NULL,NULL,NULL,NULL,1),(37,36,'object','TransTest','/Product/SKU-003/',0,0,1757512148,1757512148,2,2,'Product','Product',NULL,NULL,1),(38,27,'folder','SKU-004','/Product/',0,1,1757523779,1757523779,2,2,NULL,NULL,NULL,NULL,1),(39,38,'object','TestLog','/Product/SKU-004/',0,0,1757523779,1757524243,2,2,'Product','Product',NULL,NULL,3),(40,27,'folder','SKU-005','/Product/',0,1,1757578418,1757578418,6,6,NULL,NULL,NULL,NULL,1),(41,40,'object','Testuser','/Product/SKU-005/',0,0,1757578418,1757580577,6,8,'Product','Product',NULL,NULL,4),(42,27,'folder','SKU-006','/Product/',0,1,1757580185,1757580185,2,2,NULL,NULL,NULL,NULL,1),(43,42,'object','draftTes','/Product/SKU-006/',0,0,1757580185,1757580954,2,8,'Product','Product',NULL,NULL,8),(44,27,'folder','SKU-007','/Product/',0,1,1757581110,1757581110,6,6,NULL,NULL,NULL,NULL,1),(45,44,'object','TestTrsn','/Product/SKU-007/',0,0,1757581110,1757581584,6,8,'Product','Product',NULL,NULL,3),(46,27,'folder','SKU-008','/Product/',0,1,1757583655,1757583655,6,6,NULL,NULL,NULL,NULL,1),(47,46,'object','TestWork','/Product/SKU-008/',0,0,1757583655,1757583679,6,6,'Product','Product',NULL,NULL,2),(48,27,'folder','SKU-009','/Product/',0,1,1757595800,1757595800,2,2,NULL,NULL,NULL,NULL,1),(49,48,'object','TestPrice','/Product/SKU-009/',0,1,1757595800,1757615930,2,0,'Product','Product',NULL,NULL,7),(50,27,'folder','SKU-010','/Product/',0,1,1757620579,1757620579,1,0,NULL,NULL,NULL,NULL,1),(51,50,'object','Bottle','/Product/SKU-010/',0,1,1757620754,1757666707,0,0,'Product','Product',NULL,NULL,3),(53,1,'folder','ApiToken','/',0,1,1757650469,1757650469,2,2,NULL,NULL,NULL,NULL,2),(54,53,'object','Token','/ApiToken/',0,1,1757650480,1757650499,2,2,'ApiToken','ApiToken',NULL,NULL,3),(55,27,'folder','SKU-011','/Product/',0,1,1757688367,1757688367,1,0,NULL,NULL,NULL,NULL,1),(56,55,'object','Pot','/Product/SKU-011/',0,0,1757688871,1757688871,0,0,'Product','Product',NULL,NULL,1);
/*!40000 ALTER TABLE `objects` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12 20:39:13
