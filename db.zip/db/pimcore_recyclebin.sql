-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: pimcore
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.14-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `recyclebin`
--

DROP TABLE IF EXISTS `recyclebin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recyclebin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) DEFAULT NULL,
  `subtype` varchar(20) DEFAULT NULL,
  `path` varchar(765) DEFAULT NULL,
  `amount` int(3) DEFAULT NULL,
  `date` int(11) unsigned DEFAULT NULL,
  `deletedby` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recyclebin_date` (`date`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recyclebin`
--

LOCK TABLES `recyclebin` WRITE;
/*!40000 ALTER TABLE `recyclebin` DISABLE KEYS */;
INSERT INTO `recyclebin` VALUES (1,'object','object','/Product/Product1',1,1756722690,'pimskel'),(2,'object','object','/Product/Product1',1,1756722756,'pimskel'),(3,'object','object','/Product/SKU-01',1,1757317587,'pimskel'),(4,'object','object','/Product/SKU-01',1,1757317646,'pimskel'),(5,'object','object','/Category/Mobile',1,1757317654,'pimskel'),(6,'object','folder','/Category',1,1757318675,'pimskel'),(7,'object','object','/Category',2,1757324817,'pimskel'),(8,'object','folder','/ParentCategory',2,1757325778,'pimskel'),(9,'object','object','/Category/Category1',1,1757325790,'pimskel'),(10,'object','object','/Product/sku1',1,1757327297,'pimskel'),(11,'object','object','/Category/cat1',1,1757327717,'pimskel'),(12,'object','object','/Category/Electronics',1,1757327761,'pimskel'),(13,'object','object','/Category/Mobile',1,1757328023,'pimskel'),(14,'object','object','/Category/Electronics',1,1757328102,'pimskel'),(15,'object','folder','/Product',2,1757328297,'pimskel'),(16,'object','folder','/Category',1,1757328307,'pimskel'),(17,'object','object','/Category/Electronics/Mobiles',1,1757328567,'pimskel'),(18,'object','object','/Category/Electronics/Mobiles',1,1757329260,'pimskel'),(19,'object','object','/Category/Mobiles',1,1757329309,'pimskel'),(20,'document','folder','/Product',1,1757392177,'pimskel'),(21,'document','folder','/Category',1,1757392184,'pimskel'),(22,'object','object','/Product/TestPro',1,1757474517,'pimskel'),(23,'object','object','/Product/TestPro',1,1757475202,'pimskel'),(24,'object','folder','/Product/SKU-001',2,1757475688,'pimskel'),(25,'object','object','/Product/SKU-003/TransTest',1,1757516029,'pimskel'),(26,'object','object','/Product/SKU-003/TransTest',1,1757523756,'pimskel'),(27,'object','folder','/Product/SKU-003',2,1757580166,'pimskel'),(28,'object','object','/ApiToken',1,1757650457,'pimskel'),(29,'object','folder','/Product/SKU-001',1,1757667679,'pimskel');
/*!40000 ALTER TABLE `recyclebin` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12 20:39:13
