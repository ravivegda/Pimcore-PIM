-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: pimcore
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.14-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `object_Category`
--

DROP TABLE IF EXISTS `object_Category`;
/*!50001 DROP VIEW IF EXISTS `object_Category`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `object_Category` AS SELECT 
 1 AS `oo_id`,
 1 AS `oo_classId`,
 1 AS `oo_className`,
 1 AS `name`,
 1 AS `description`,
 1 AS `parentCategory__id`,
 1 AS `parentCategory__type`,
 1 AS `products`,
 1 AS `id`,
 1 AS `parentId`,
 1 AS `type`,
 1 AS `key`,
 1 AS `path`,
 1 AS `index`,
 1 AS `published`,
 1 AS `creationDate`,
 1 AS `modificationDate`,
 1 AS `userOwner`,
 1 AS `userModification`,
 1 AS `classId`,
 1 AS `className`,
 1 AS `childrenSortBy`,
 1 AS `childrenSortOrder`,
 1 AS `versionCount`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `object_Product`
--

DROP TABLE IF EXISTS `object_Product`;
/*!50001 DROP VIEW IF EXISTS `object_Product`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `object_Product` AS SELECT 
 1 AS `oo_id`,
 1 AS `oo_classId`,
 1 AS `oo_className`,
 1 AS `productName`,
 1 AS `description`,
 1 AS `productId`,
 1 AS `createdAt`,
 1 AS `productImage`,
 1 AS `SKU`,
 1 AS `nextAvailableOn`,
 1 AS `category__id`,
 1 AS `category__type`,
 1 AS `parentProduct__id`,
 1 AS `parentProduct__type`,
 1 AS `stockQuantity`,
 1 AS `priceUpdatedAt`,
 1 AS `price`,
 1 AS `workflowTransition`,
 1 AS `id`,
 1 AS `parentId`,
 1 AS `type`,
 1 AS `key`,
 1 AS `path`,
 1 AS `index`,
 1 AS `published`,
 1 AS `creationDate`,
 1 AS `modificationDate`,
 1 AS `userOwner`,
 1 AS `userModification`,
 1 AS `classId`,
 1 AS `className`,
 1 AS `childrenSortBy`,
 1 AS `childrenSortOrder`,
 1 AS `versionCount`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `object_ApiToken`
--

DROP TABLE IF EXISTS `object_ApiToken`;
/*!50001 DROP VIEW IF EXISTS `object_ApiToken`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `object_ApiToken` AS SELECT 
 1 AS `oo_id`,
 1 AS `oo_classId`,
 1 AS `oo_className`,
 1 AS `token`,
 1 AS `id`,
 1 AS `parentId`,
 1 AS `type`,
 1 AS `key`,
 1 AS `path`,
 1 AS `index`,
 1 AS `published`,
 1 AS `creationDate`,
 1 AS `modificationDate`,
 1 AS `userOwner`,
 1 AS `userModification`,
 1 AS `classId`,
 1 AS `className`,
 1 AS `childrenSortBy`,
 1 AS `childrenSortOrder`,
 1 AS `versionCount`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `object_Category`
--

/*!50001 DROP VIEW IF EXISTS `object_Category`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pimcore`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_Category` AS select `object_query_Category`.`oo_id` AS `oo_id`,`object_query_Category`.`oo_classId` AS `oo_classId`,`object_query_Category`.`oo_className` AS `oo_className`,`object_query_Category`.`name` AS `name`,`object_query_Category`.`description` AS `description`,`object_query_Category`.`parentCategory__id` AS `parentCategory__id`,`object_query_Category`.`parentCategory__type` AS `parentCategory__type`,`object_query_Category`.`products` AS `products`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount` from (`object_query_Category` join `objects` on(`objects`.`id` = `object_query_Category`.`oo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_Product`
--

/*!50001 DROP VIEW IF EXISTS `object_Product`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pimcore`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_Product` AS select `object_query_Product`.`oo_id` AS `oo_id`,`object_query_Product`.`oo_classId` AS `oo_classId`,`object_query_Product`.`oo_className` AS `oo_className`,`object_query_Product`.`productName` AS `productName`,`object_query_Product`.`description` AS `description`,`object_query_Product`.`productId` AS `productId`,`object_query_Product`.`createdAt` AS `createdAt`,`object_query_Product`.`productImage` AS `productImage`,`object_query_Product`.`SKU` AS `SKU`,`object_query_Product`.`nextAvailableOn` AS `nextAvailableOn`,`object_query_Product`.`category__id` AS `category__id`,`object_query_Product`.`category__type` AS `category__type`,`object_query_Product`.`parentProduct__id` AS `parentProduct__id`,`object_query_Product`.`parentProduct__type` AS `parentProduct__type`,`object_query_Product`.`stockQuantity` AS `stockQuantity`,`object_query_Product`.`priceUpdatedAt` AS `priceUpdatedAt`,`object_query_Product`.`price` AS `price`,`object_query_Product`.`workflowTransition` AS `workflowTransition`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount` from (`object_query_Product` join `objects` on(`objects`.`id` = `object_query_Product`.`oo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_ApiToken`
--

/*!50001 DROP VIEW IF EXISTS `object_ApiToken`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pimcore`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_ApiToken` AS select `object_query_ApiToken`.`oo_id` AS `oo_id`,`object_query_ApiToken`.`oo_classId` AS `oo_classId`,`object_query_ApiToken`.`oo_className` AS `oo_className`,`object_query_ApiToken`.`token` AS `token`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount` from (`object_query_ApiToken` join `objects` on(`objects`.`id` = `object_query_ApiToken`.`oo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12 20:39:14
