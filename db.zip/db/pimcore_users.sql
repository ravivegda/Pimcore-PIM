-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: pimcore
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.14-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(11) unsigned DEFAULT NULL,
  `type` enum('user','userfolder','role','rolefolder') NOT NULL DEFAULT 'user',
  `name` varchar(50) DEFAULT NULL,
  `password` varchar(190) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `language` varchar(10) DEFAULT 'en',
  `datetimeLocale` varchar(10) DEFAULT '',
  `contentLanguages` longtext DEFAULT NULL,
  `admin` tinyint(1) unsigned DEFAULT 0,
  `active` tinyint(1) unsigned DEFAULT 1,
  `permissions` text DEFAULT NULL,
  `roles` varchar(1000) DEFAULT NULL,
  `welcomescreen` tinyint(1) DEFAULT NULL,
  `closeWarning` tinyint(1) DEFAULT NULL,
  `memorizeTabs` tinyint(1) DEFAULT NULL,
  `allowDirtyClose` tinyint(1) unsigned DEFAULT 1,
  `docTypes` text DEFAULT NULL,
  `classes` text DEFAULT NULL,
  `twoFactorAuthentication` varchar(255) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `activePerspective` varchar(255) DEFAULT NULL,
  `perspectives` longtext DEFAULT NULL,
  `websiteTranslationLanguagesEdit` longtext DEFAULT NULL,
  `websiteTranslationLanguagesView` longtext DEFAULT NULL,
  `lastLogin` int(11) unsigned DEFAULT NULL,
  `keyBindings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`keyBindings`)),
  `passwordRecoveryToken` varchar(290) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type_name` (`type`,`name`),
  KEY `parentId` (`parentId`),
  KEY `name` (`name`),
  KEY `password` (`password`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (0,0,'user','system',NULL,NULL,NULL,NULL,'en','',NULL,1,1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,0,'user','pimskel','$2y$10$pvLOSKctQVGGGb52tMSdO.JCWoSh3ttpRM1uHdN5p.2GgA3nc2z9.','','','','en','','en,de,fr',1,1,'assets,asset_metadata,classes,classificationstore,clear_cache,clear_fullpage_cache,clear_temp_files,dashboards,documents,document_types,emails,fieldcollections,notes_events,notifications,notifications_send,objectbricks,objects,objects_sort_method,predefined_properties,quantityValueUnits,recyclebin,redirects,seemode,selectoptions,share_configurations,sites,system_settings,tags_assignment,tags_configuration,tags_search,thumbnails,translations,users,website_settings,workflow_details','',0,0,0,1,'','','{\"required\":false,\"enabled\":false,\"secret\":\"\",\"type\":\"\"}',NULL,'default','','','',1757682927,'[{\"key\":83,\"action\":\"save\",\"ctrl\":true,\"alt\":false,\"shift\":false},{\"key\":80,\"action\":\"publish\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":85,\"action\":\"unpublish\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":82,\"action\":\"rename\",\"alt\":true,\"shift\":true,\"ctrl\":false},{\"key\":116,\"action\":\"refresh\",\"alt\":false,\"ctrl\":false,\"shift\":false},{\"key\":68,\"action\":\"openDocument\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":65,\"action\":\"openAsset\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":79,\"action\":\"openObject\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":67,\"action\":\"openClassEditor\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":76,\"action\":\"openInTree\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":73,\"action\":\"showMetaInfo\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":87,\"action\":\"searchDocument\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":65,\"action\":\"searchAsset\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":79,\"action\":\"searchObject\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":72,\"action\":\"showElementHistory\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":84,\"action\":\"closeAllTabs\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":83,\"action\":\"searchAndReplaceAssignments\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":82,\"action\":\"redirects\",\"ctrl\":false,\"alt\":true,\"shift\":false},{\"key\":84,\"action\":\"sharedTranslations\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":82,\"action\":\"recycleBin\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":78,\"action\":\"notesEvents\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":72,\"action\":\"tagManager\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":78,\"action\":\"tagConfiguration\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":85,\"action\":\"users\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":80,\"action\":\"roles\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":81,\"action\":\"clearAllCaches\",\"ctrl\":false,\"alt\":true,\"shift\":false},{\"key\":67,\"action\":\"clearDataCache\",\"ctrl\":false,\"alt\":true,\"shift\":false}]',NULL),(6,0,'user','creator','$2y$10$S3w1c3jDRuNGcwtyOKeF7eNccbV5Sa99KIFW6eFy5Ye9r.Bp2Fr8.','','','','en','','en,de,fr',0,1,'assets,asset_metadata,classes,classificationstore,clear_cache,clear_fullpage_cache,clear_temp_files,dashboards,documents,document_types,emails,fieldcollections,notes_events,notifications,notifications_send,objectbricks,objects,objects_sort_method,predefined_properties,quantityValueUnits,recyclebin,redirects,seemode,selectoptions,share_configurations,sites,system_settings,tags_assignment,tags_configuration,tags_search,thumbnails,translations,website_settings,workflow_details','12',0,1,1,0,'','Product','{\"required\":false,\"enabled\":false,\"secret\":\"\",\"type\":\"\"}',NULL,NULL,'','','',1757583644,'[{\"key\":83,\"action\":\"save\",\"ctrl\":true,\"alt\":false,\"shift\":false},{\"key\":80,\"action\":\"publish\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":85,\"action\":\"unpublish\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":82,\"action\":\"rename\",\"alt\":true,\"shift\":true,\"ctrl\":false},{\"key\":116,\"action\":\"refresh\",\"alt\":false,\"ctrl\":false,\"shift\":false},{\"key\":68,\"action\":\"openDocument\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":65,\"action\":\"openAsset\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":79,\"action\":\"openObject\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":67,\"action\":\"openClassEditor\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":76,\"action\":\"openInTree\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":73,\"action\":\"showMetaInfo\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":87,\"action\":\"searchDocument\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":65,\"action\":\"searchAsset\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":79,\"action\":\"searchObject\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":72,\"action\":\"showElementHistory\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":84,\"action\":\"closeAllTabs\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":83,\"action\":\"searchAndReplaceAssignments\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":82,\"action\":\"redirects\",\"ctrl\":false,\"alt\":true,\"shift\":false},{\"key\":84,\"action\":\"sharedTranslations\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":82,\"action\":\"recycleBin\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":78,\"action\":\"notesEvents\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":72,\"action\":\"tagManager\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":78,\"action\":\"tagConfiguration\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":85,\"action\":\"users\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":80,\"action\":\"roles\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":81,\"action\":\"clearAllCaches\",\"ctrl\":false,\"alt\":true,\"shift\":false},{\"key\":67,\"action\":\"clearDataCache\",\"ctrl\":false,\"alt\":true,\"shift\":false}]',NULL),(7,0,'user','reviewer','$2y$10$HIkN8mnFoUTKL3ZkqXNe4u36NsHEFigwJjZ3d/jrgHfwP/0aFlrrG','','','','en','','en,de,fr',0,1,'assets,asset_metadata,classes,classificationstore,clear_cache,clear_fullpage_cache,clear_temp_files,dashboards,documents,document_types,emails,fieldcollections,notes_events,notifications,notifications_send,objectbricks,objects,objects_sort_method,predefined_properties,quantityValueUnits,recyclebin,redirects,seemode,selectoptions,share_configurations,sites,system_settings,tags_assignment,tags_configuration,tags_search,thumbnails,translations,website_settings,workflow_details','',0,1,1,0,'','Product','{\"required\":false,\"enabled\":false,\"secret\":\"\",\"type\":\"\"}',NULL,NULL,'','','',1757516440,'[{\"key\":83,\"action\":\"save\",\"ctrl\":true,\"alt\":false,\"shift\":false},{\"key\":80,\"action\":\"publish\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":85,\"action\":\"unpublish\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":82,\"action\":\"rename\",\"alt\":true,\"shift\":true,\"ctrl\":false},{\"key\":116,\"action\":\"refresh\",\"alt\":false,\"ctrl\":false,\"shift\":false},{\"key\":68,\"action\":\"openDocument\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":65,\"action\":\"openAsset\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":79,\"action\":\"openObject\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":67,\"action\":\"openClassEditor\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":76,\"action\":\"openInTree\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":73,\"action\":\"showMetaInfo\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":87,\"action\":\"searchDocument\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":65,\"action\":\"searchAsset\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":79,\"action\":\"searchObject\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":72,\"action\":\"showElementHistory\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":84,\"action\":\"closeAllTabs\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":83,\"action\":\"searchAndReplaceAssignments\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":82,\"action\":\"redirects\",\"ctrl\":false,\"alt\":true,\"shift\":false},{\"key\":84,\"action\":\"sharedTranslations\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":82,\"action\":\"recycleBin\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":78,\"action\":\"notesEvents\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":72,\"action\":\"tagManager\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":78,\"action\":\"tagConfiguration\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":85,\"action\":\"users\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":80,\"action\":\"roles\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":81,\"action\":\"clearAllCaches\",\"ctrl\":false,\"alt\":true,\"shift\":false},{\"key\":67,\"action\":\"clearDataCache\",\"ctrl\":false,\"alt\":true,\"shift\":false}]',NULL),(8,0,'user','approver','$2y$10$ssbK5gUiwu0gAx.g4B5zo.XVjzpUcAD9920nCM16NOat8s7HwwIQy','','','','en','','en,de,fr',0,1,'assets,asset_metadata,classes,classificationstore,clear_cache,clear_fullpage_cache,clear_temp_files,dashboards,documents,document_types,emails,fieldcollections,notes_events,notifications,notifications_send,objectbricks,objects,objects_sort_method,predefined_properties,quantityValueUnits,recyclebin,redirects,seemode,selectoptions,share_configurations,sites,system_settings,tags_assignment,tags_configuration,tags_search,thumbnails,translations,website_settings,workflow_details','13',0,1,1,0,'','Product','{\"required\":false,\"enabled\":false,\"secret\":\"\",\"type\":\"\"}',NULL,NULL,'','','',1757583715,'[{\"key\":83,\"action\":\"save\",\"ctrl\":true,\"alt\":false,\"shift\":false},{\"key\":80,\"action\":\"publish\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":85,\"action\":\"unpublish\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":82,\"action\":\"rename\",\"alt\":true,\"shift\":true,\"ctrl\":false},{\"key\":116,\"action\":\"refresh\",\"alt\":false,\"ctrl\":false,\"shift\":false},{\"key\":68,\"action\":\"openDocument\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":65,\"action\":\"openAsset\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":79,\"action\":\"openObject\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":67,\"action\":\"openClassEditor\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":76,\"action\":\"openInTree\",\"ctrl\":true,\"shift\":true,\"alt\":false},{\"key\":73,\"action\":\"showMetaInfo\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":87,\"action\":\"searchDocument\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":65,\"action\":\"searchAsset\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":79,\"action\":\"searchObject\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":72,\"action\":\"showElementHistory\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":84,\"action\":\"closeAllTabs\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":83,\"action\":\"searchAndReplaceAssignments\",\"alt\":true,\"ctrl\":false,\"shift\":false},{\"key\":82,\"action\":\"redirects\",\"ctrl\":false,\"alt\":true,\"shift\":false},{\"key\":84,\"action\":\"sharedTranslations\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":82,\"action\":\"recycleBin\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":78,\"action\":\"notesEvents\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":72,\"action\":\"tagManager\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":78,\"action\":\"tagConfiguration\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":85,\"action\":\"users\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":80,\"action\":\"roles\",\"ctrl\":true,\"alt\":true,\"shift\":false},{\"key\":81,\"action\":\"clearAllCaches\",\"ctrl\":false,\"alt\":true,\"shift\":false},{\"key\":67,\"action\":\"clearDataCache\",\"ctrl\":false,\"alt\":true,\"shift\":false}]',NULL),(12,0,'role','PRODUCT_CREATOR',NULL,NULL,NULL,NULL,'en','',NULL,0,1,'',NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'','','',NULL,NULL,NULL),(13,0,'role','PRODUCT_APPROVER',NULL,NULL,NULL,NULL,'en','',NULL,0,1,'',NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'','','',NULL,NULL,NULL),(14,0,'role','PRODUCT_REVIEWER',NULL,NULL,NULL,NULL,'en','',NULL,0,1,'',NULL,NULL,NULL,NULL,1,'','Product',NULL,NULL,NULL,'','','',NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12 20:39:13
